import { useState } from "react";
import { Conversation } from "@/data/conversations";
import { cn } from "@/lib/utils";
import { Star } from "lucide-react";

const AVATAR_COLORS = [
  "#f9a825", "#1a73e8", "#34a853", "#ea4335",
  "#7e57c2", "#ec407a", "#26a69a", "#ff7043",
  "#5c6bc0", "#26c6da", "#9ccc65", "#ab47bc",
];

function avatarColor(name: string) {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
  return AVATAR_COLORS[hash % AVATAR_COLORS.length];
}

function initial(name: string) {
  return name.trim().charAt(0).toUpperCase() || "?";
}

interface MessageRowProps {
  conversation: Conversation;
}

export function MessageRow({ conversation }: MessageRowProps) {
  const [starred, setStarred] = useState(false);
  const color = avatarColor(conversation.sender);

  return (
    <div className="flex items-start gap-3 px-4 py-3 bg-white hover:bg-[#f6f8fc] active:bg-[#eef1f6] cursor-pointer border-b border-[#f1f3f4]">
      <div
        className="w-10 h-10 rounded-full flex items-center justify-center text-white text-[16px] font-medium flex-shrink-0"
        style={{ backgroundColor: color }}
        aria-hidden="true"
      >
        {initial(conversation.sender)}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-baseline justify-between gap-2">
          <span
            className={cn(
              "truncate text-[15px] text-[#202124]",
              conversation.unread ? "font-semibold" : "font-normal"
            )}
          >
            {conversation.sender}
          </span>
          <span
            className={cn(
              "text-[12px] flex-shrink-0",
              conversation.unread ? "text-[#202124] font-medium" : "text-[#5f6368]"
            )}
          >
            {conversation.timestamp}
          </span>
        </div>

        <div
          className={cn(
            "truncate text-[14px] mt-0.5",
            conversation.unread ? "font-semibold text-[#202124]" : "font-normal text-[#5f6368]"
          )}
        >
          {conversation.subject}
        </div>

        <div className="truncate text-[13px] text-[#5f6368] mt-0.5">
          {conversation.preview}
        </div>
      </div>

      <button
        aria-label={starred ? "Unstar" : "Star"}
        onClick={(e) => {
          e.stopPropagation();
          setStarred((s) => !s);
        }}
        className="flex-shrink-0 w-8 h-8 -mr-1 flex items-center justify-center text-[#5f6368] hover:text-[#202124] transition-colors"
      >
        <Star
          className={cn("w-5 h-5", starred && "text-[#f9a825]")}
          fill={starred ? "currentColor" : "none"}
          strokeWidth={1.5}
        />
      </button>
    </div>
  );
}
